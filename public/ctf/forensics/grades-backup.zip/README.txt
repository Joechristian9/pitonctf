Sir Joe Christian, I locked the grades backup like you asked.
The password is pinecone2024. I wrote it here so you won't forget it!
- your student assistant
